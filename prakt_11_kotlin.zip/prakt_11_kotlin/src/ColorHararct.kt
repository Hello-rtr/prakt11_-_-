enum class ColorHaract (var Description: String) {
    RED("Яркий"){
        override fun ottenok() = "Цвет красного зонта"
        override fun rascvetka() = "Одноцветный"
        override fun using() = "Используется для сигнальных знаков"
        override fun associat() = "Ассоциируется с любовью"
    },
    BLUE("Прохладный"){
        override fun ottenok() = "Цвет неба"
        override fun rascvetka() = "Много оттенков"
        override fun using() = "Используется в декоре и одежде"
        override fun associat() = "Ассоциируется со свободой"
    },
    GREEN("Свежий"){
        override fun ottenok() = "Цвет травы"
        override fun rascvetka() = "Много оттенков"
        override fun using() = "Используется в медицине и психотерапии для улучшения настроения и снятия стресса"
        override fun associat() = "Ассоциируется с природой"
    },
    YELLOW("Солнечный"){
        override fun ottenok() = "Цвет подсолнечника"
        override fun rascvetka() = "Яркий"
        override fun using() = "Используется для создания ярких акцентов"
        override fun associat() = "Ассоциируется с теплом"
    };
    abstract fun ottenok(): String;
    abstract fun rascvetka(): String;
    abstract fun using(): String;
    abstract fun associat(): String;
}
