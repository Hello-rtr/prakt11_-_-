enum class WeekDays (var dayNumber: Int){
    Monday(1),
    Tuesday(2),
    Wednesday(3),
    Thursday(4),
    Friday(5),
    Saturday(6),
    Sunday(7)
}
enum class Color(var colorNumber: Int){
    RED(1),
    GREEN(2),
    BLUE(3),
    YELLOW(4),
    ORANGE(5),
    PURPLE(6),
    BLACK(7)
}
fun getWeekDayByNumber(number: Int) : WeekDays? {
    return WeekDays.values().find { it.dayNumber == number }
}
fun IsWeekend(day:WeekDays): Boolean
{
    return day == WeekDays.Saturday || day == WeekDays.Sunday
}
fun isWarmColor(color: Color) : Boolean
{
    return color == Color.RED || color == Color.ORANGE || color == Color.YELLOW
}
fun getColorByNumber(number: Int) : Color?
{
    return Color.values().find { it.colorNumber == number }
}
