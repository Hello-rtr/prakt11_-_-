fun main() {
    println("Номер дня:")
    WeekDays.values().forEach { day -> println("${day.name} - ${day.dayNumber}")}
    println("Введите номер дня (от 1 до 7): ")
    var dayNumber = readln().toInt()
    var day = getWeekDayByNumber(dayNumber)
    if (day != null)
    {
        println("${day.name} это выходной: ${IsWeekend(day)}")
    }
    else
    {
        println("Ошибка")
    }
    println("\nНомер цвета:")
    Color.values().forEach { color -> println("${color.name} - ${color.colorNumber}") }
    ColorHaract.values().forEach { color -> println("${color.name}: ${color.ottenok()}; ${color.rascvetka()}; ${color.using()}; ${color.associat()}") }
    var colorNumber = readln().toInt()
    var color = getColorByNumber(colorNumber)
    if (color != null)
    {
        println("${color.name} является теплым: ${isWarmColor(color)}")
    }
    else
    {
        println("Ошибка")
    }
}
